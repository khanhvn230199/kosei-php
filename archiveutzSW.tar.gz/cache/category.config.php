<?
$_CAT_SLUG = array(
		'khoa-hoc-n3-online' => 1,
		'combo-n4-n3' => 4,
		'combo-n3-n2' => 4,
		'combo-n4-n3-n2' => 4,
		'giao-vien' => 2,
		'giao-trinh' => 3,
		'tin-tuc' => 0,
		'khoa-hoc-n5-online' => 1,
		'khoa-hoc-n4-online' => 1,
		'khoa-hoc-n2-online' => 1,
		'khoa-hoc-n1-online' => 1,
);
?>