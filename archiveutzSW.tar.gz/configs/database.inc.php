<?
/******************************************************
 * DB Configuration
 *
 * Config some infos of database like: host,user,pass
 *
 *
 * Project Name               :  ClientWebsite
 * Package Name                    :
 * Program ID                 :  database.inc.php
 * Environment                :  PHP  version 5.3
 * Author                     :  TuanTA
 * Version                    :  1.0
 * Creation Date              :  20/01/2018
 *
 * Modification History     :
 * Version    Date            Person Name          Chng  Req   No    Remarks
 * 1.0           20/01/2018        Tuanta          -          -     -     -
 *
 ********************************************************/

define("DB_HOST", "localhost");
define("DB_USER", "koseionline_usr");
define("DB_PASS", "rRLu27BlYQbYwR4F");
define("DB_NAME", "koseionline_db");
define("DB_TYPE", "mysqli");
